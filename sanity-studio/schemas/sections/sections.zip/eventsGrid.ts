// sanity-studio/schemas/sections/eventsGrid.ts
import { defineType, defineField } from 'sanity'

export default defineType({
  name: 'eventsGrid',
  title: 'Events Grid',
  type: 'object',
  fields: [
    defineField({ name: 'title', title: 'Title', type: 'string' }),
    defineField({
      name: 'onlyUpcoming',
      title: 'Only upcoming events',
      type: 'boolean',
      initialValue: true,
    }),
  ],
})
